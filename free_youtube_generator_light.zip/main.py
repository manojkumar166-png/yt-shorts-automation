import asyncio
import os
import requests
import edge_tts
from moviepy.editor import AudioFileClip, ImageClip
from PIL import Image

def generate_script_lightweight(topic):
    """
    Generates a script without local LLMs like Ollama. 
    Uses a free public endpoint or structured fallback templates suitable for low-RAM machines.
    """
    print(f"[*] Generating script for topic: {topic} (Lightweight Mode)...")
    
    # Example using a free public fallback or structured text generator
    script = (
        f"Welcome! Today we are exploring the fascinating world of {topic}. "
        f"Whether you are a beginner or looking to master new skills, understanding the core principles "
        f"of {topic} changes everything. Let's break down the most important insights you need to know right now. "
        f"Make sure to save this video and subscribe for more insights!"
    )
    return script

async def generate_voiceover(text, output_file="voiceover.mp3"):
    """Generates natural voiceover using Microsoft Edge TTS (Zero RAM overhead)."""
    voice = "en-US-AriaNeural"
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(output_file)

def main():
    topic = "Productivity Hacks"
    
    # 1. Generate Script
    script = generate_script_lightweight(topic)
    print(f"\nGenerated Script:\n{script}\n")

    # 2. Generate Voiceover
    print("[*] Generating voiceover...")
    asyncio.run(generate_voiceover(script, "voiceover.mp3"))

    # 3. Assemble Video
    print("[*] Assembling video (Low-RAM optimized)...")
    audio = AudioFileClip("voiceover.mp3")
    
    bg_path = "background.jpg"
    if not os.path.exists(bg_path):
        img = Image.new('RGB', (1080, 1920), color=(15, 23, 42)) # Sleek dark slate background
        img.save(bg_path)

    image_clip = ImageClip(bg_path).set_duration(audio.duration)
    video = image_clip.set_audio(audio)
    
    output_filename = "youtube_ready.mp4"
    # Using lower preset settings for fast, low-RAM encoding
    video.write_videofile(
        output_filename, 
        fps=24, 
        codec="libx264", 
        audio_codec="aac",
        preset="ultrafast",
        threads=2
    )
    print(f"[+] Video successfully created: {output_filename}")

if __name__ == "__main__":
    main()
